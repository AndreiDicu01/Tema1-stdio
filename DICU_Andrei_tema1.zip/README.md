# TEMA1-PSO : stdio

## `Structura so_file`
Am introdus handle-ul , un buffer de 4096, offset-uri pentru buffer cu care citim fisierul si unul pentru cursor,
is_eof prin care realizam verificarea daca s-a ajuns la EOF, to_eof ce obtine valoarea nr de bytes cititi in ultima functie

## `fopen`
Am realizat deschiderile fisierelor tinand cont de fiecare restrictie asupra acestora in functie de modul de deschidere. Bineinteles, am initializat toti membrii statici din structura cu valorile implicite deschiderii unui fisier.

## `fflush`
Daca flag-ul de flush este > 0 a fost realizata o scriere si facem flush dupa cara ramanem la offsetul la care eram

## `fgetc`
Verificari prin care obtinem daca pozitia cursorului a ajuns la ultimul caracter si daca offset-ul bufferului trebui alocat.

## `fputc`
## `fseek`
## `ftell`
