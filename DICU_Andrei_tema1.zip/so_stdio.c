#if defined(__linux__)
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include "./so_stdio.h"
#elif defined(_WIN32)
#include <fileapi.h>
#include <string.h>
#include <stdio.h>
#include "./so_stdio.h"
#endif

#define BUFSIZE 4096
#define MODE 0664

struct _so_file
{
#if defined(__linux__)
    int handle;

#elif defined(_WIN32)
    HANDLE handle;

#else
#error "Unknown platform"
#endif

    char buffer[BUFSIZE];

    int offset_now;
    int offset_base;

    int is_eof;
    int to_eof;
    int flushed;

    int last_error;

#if defined(__linux__)
    mode_t mod;
#endif

#if defined(__linux__)
    int flag;
#elif defined(_WIN32)
    DWORD flag;
#endif


    int file_flag;
    int process_flag;

    int read_flag;
    int write_flag;
    int none_flag;
};

typedef enum
{
    err_write = 1,
    err_read = 2,
    err_close = 3,
    err_stream = 4,
    err_file_type = 5,
    err_invalid_seek = 6,
    err_invalid_mem = 7,
    err_try_again = 8
} LAST_ERROR;

typedef struct _so_file SO_FILE;

SO_FILE *so_fopen(const char *pathname, const char *mode)
{
    SO_FILE *result;
#if defined(__linux__)
    int flag;
    mode_t permisiuni = 0;
    int res_open;

    if (pathname == NULL)
    {
        return NULL;
    }
    if (mode == NULL)
    {
        return NULL;
    }

    if (strcmp(mode, "r") == 0)
    {
        flag = O_RDONLY;
    }
    else if (strcmp(mode, "r+") == 0)
    {
        flag = O_RDWR;
    }
    else if (strcmp(mode, "w") == 0)
    {
        flag = O_WRONLY | O_TRUNC | O_CREAT;
        permisiuni = MODE;
    }
    else if (strcmp(mode, "w+") == 0)
    {
        flag = O_RDWR | O_TRUNC | O_CREAT;
        permisiuni = MODE;
    }
    else if (strcmp(mode, "a") == 0)
    {
        flag = O_WRONLY | O_APPEND | O_CREAT;
        permisiuni = MODE;
    }
    else if (strcmp(mode, "a+") == 0)
    {
        flag = O_RDWR | O_APPEND | O_CREAT;
        permisiuni = MODE;
    }
    else
    {
        return NULL;
    }

    if (permisiuni != 0)
    {
        res_open = open(pathname, flag, permisiuni);
    }
    else
    {
        res_open = open(pathname, flag);
    }
    if (res_open < 0)
    {
        return NULL;
    }
    result = malloc(sizeof(SO_FILE));
    if (result == NULL)
    {
        return NULL;
    }

    result->offset_now = 0;
    result->is_eof = -1;
    result->to_eof = -1;

    result->last_error = 0;

    result->handle = res_open;
    result->flag = flag;
    result->mod = permisiuni;
    result->file_flag = 1;
    result->process_flag = 0;

    memset(result->buffer, 0, BUFSIZE);
    result->offset_base = -1;
    result->flushed = 0;
    result->none_flag = 1;
    result->write_flag = 0;
    result->read_flag = 0;

    //printf("Fopen pe %d(handle) : done\n", res_open);

    return result;
#elif defined(_WIN32)
    HANDLE hFILE;
    DWORD acces_mode;
    DWORD share_mode;
    DWORD creation_disposition;
    DWORD flags;
    DWORD dwMoved;
    flags = FILE_ATTRIBUTE_NORMAL;

    if (pathname == NULL)
    {
        return NULL;
    }
    if (mode == NULL)
    {
        return NULL;
    }
    if (strcmp(mode, "r") == 0)
    {
        acces_mode = GENERIC_READ;
        share_mode = FILE_SHARE_READ;
        creation_disposition = OPEN_EXISTING;
    }
    else if (strcmp(mode, "r+") == 0)
    {
        acces_mode = GENERIC_READ | GENERIC_WRITE;
        share_mode = FILE_SHARE_READ | FILE_SHARE_WRITE;
        creation_disposition = OPEN_EXISTING;
    }
    else if (strcmp(mode, "w") == 0)
    {
        acces_mode = GENERIC_WRITE;
        share_mode = FILE_SHARE_WRITE;
        creation_disposition = CREATE_ALWAYS;
    }
    else if (strcmp(mode, "w+") == 0)
    {
        acces_mode = GENERIC_READ | GENERIC_WRITE;
        share_mode = FILE_SHARE_READ | FILE_SHARE_WRITE;
        creation_disposition = CREATE_ALWAYS;
    }
    else if (strcmp(mode, "a") == 0)
    {
        acces_mode = FILE_APPEND_DATA;
        share_mode = FILE_SHARE_READ | FILE_SHARE_WRITE;
        creation_disposition = OPEN_ALWAYS;
    }
    else if (strcmp(mode, "a+") == 0)
    {
        acces_mode = FILE_APPEND_DATA | GENERIC_READ;
        share_mode = FILE_SHARE_READ | FILE_SHARE_WRITE;
        creation_disposition = OPEN_ALWAYS;
    }
    else
    {
        return NULL;
    }
    hFILE = CreateFile(pathname, acces_mode, share_mode, NULL, creation_disposition, flags, NULL);
    if (hFILE == INVALID_HANDLE_VALUE)
    {
        return NULL;
    }

    if (strcmp(mode, "a") == 0)
    {
        dwMoved = SetFilePointer(hFILE, 0l, NULL, FILE_END);
        if (dwMoved == INVALID_SET_FILE_POINTER)
        {
            return NULL;
        }
    }
    result = malloc(sizeof(SO_FILE));
    if (result == NULL)
    {
        return NULL;
    }

    result->offset_now = 0;
    result->is_eof = -1;
    result->to_eof = -1;

    result->last_error = ERROR_SUCCESS;
    result->handle = hFILE;
    result->flag = acces_mode;
    result->file_flag = 1;
    result->process_flag = 0;

    // memset(result->buffer, 0, BUFSIZE);
    ZeroMemory(result->buffer, BUFSIZE);
    result->offset_base = -1;
    result->flushed = 0;
    result->none_flag = 1;
    result->write_flag = 0;
    result->read_flag = 0;

    return result;
#endif
}

int so_fclose(SO_FILE *stream)
{
#if defined(__linux__)
    int last_error;
    if (stream == NULL)
    {
        return -1;
    }
    if (stream->file_flag != 1)
    {

        stream->last_error = err_close;
        free(stream);
        return -1;
    }
    
        so_fflush(stream);
    
   // printf("Fclose pe %d(handle) : done\n", stream->handle);
    // if (stream->last_error != 0)
    //{
    //     return -1;
    //}
    int res_close = close(stream->handle);
    if (res_close < 0)
    {
        stream->last_error = err_close;
        free(stream);

        return -1;
    }
    last_error = stream->last_error;
    //printf("%d", last_error);

    free(stream);
    stream = NULL;

    if (last_error != 0)
    {
        return -1;
    }

    return 0;
#elif defined(_WIN32)
    int last_error;
    BOOL bRET;

    if (stream == NULL)
    {
        return -1;
    }
    if (stream->file_flag != 1)
    {
        stream->last_error = err_close;
        return -1;
    }
    if (stream->flushed > 0)
    {
        so_fflush(stream);
    }
    bRET = CloseHandle(stream->handle);
    free(stream);
    stream = NULL;

    return 0;
#endif
}

int so_fflush(SO_FILE *stream)
{
#if defined(__linux__)
    int res_write;
    if (stream == NULL)
    {
        return -1;
    }

    if (stream->flushed > 0)
    {

        res_write = write(stream->handle, stream->buffer, stream->offset_now - stream->offset_base);

        if (res_write == -1)
        {
            stream->last_error = err_write;
            return -1;
        }
        memset(stream->buffer, 0, BUFSIZE);
        stream->offset_base = -1;
        stream->flushed = 0;
        stream->none_flag = 1;
        stream->read_flag=0;
        stream->write_flag=0;
    }
    return 0;
#elif defined(_WIN32)
    BOOL bRET;
    DWORD bytesToWrite;
    DWORD bytesWritten;
    if (stream == NULL)
    {
        return -1;
    }
    if (stream->flushed > 0)
    {
        bytesToWrite = stream->offset_now - stream->offset_base;
        bRET = WriteFile(stream->handle, stream->buffer, bytesToWrite, &bytesWritten, NULL);
        if (bRET == FALSE)
        {
            stream->last_error = err_write;
            return -1;
        }
        if (bytesToWrite != bytesWritten)
        {
            stream->last_error = err_write;
            return -1;
        }
        ZeroMemory(stream->buffer, BUFSIZE);
        stream->offset_base = -1;
        stream->flushed = 0;
        stream->none_flag = 1;
        stream->write_flag = 0;
        stream->read_flag = 0;
    }
    return 0;
#endif
}

int so_fseek(SO_FILE *stream, long offset, int whence)
{
#if defined(__linux__)
    if (stream == NULL)
    {
        return -1;
    }
    if (stream->file_flag != 1)
    {
        stream->last_error = err_file_type;
        return -1;
    }

    int position;

    if (stream->write_flag == 1)
    {
        so_fflush(stream);
    }

    position = lseek(stream->handle, offset, whence);
    if (position < 0)
    {
        stream->last_error = err_invalid_seek;
        return -1;
    }
    //
    stream->offset_now = position;
    if (offset < 0 && whence == SEEK_CUR && stream->write_flag == 1)
    {
        stream->offset_base = -1;
    }
    if (stream->read_flag == 1)
    {
        memset(stream->buffer, 0, BUFSIZE);
        stream->offset_base = -1;
        stream->flushed = 0;
        stream->none_flag = 1;
        stream->write_flag = 0;
        stream->read_flag = 0;
    }
    stream->last_error = 0;
    return 0;
#elif defined(_WIN32)
    if (stream == NULL)
    {
        return -1;
    }
    if (stream->file_flag != 1)
    {
        stream->last_error = err_file_type;
        return -1;
    }
    DWORD position;

    if (!(whence == SEEK_SET || whence == SEEK_END || whence == SEEK_CUR))
    {
        stream->last_error = err_invalid_seek;
        return -1;
    }
    position = SetFilePointer(stream->handle, offset, NULL, whence);
    if (position == INVALID_SET_FILE_POINTER)
    {
        stream->last_error = err_invalid_seek;
        return -1;
    }
    stream->offset_now = position;
    if (offset < 0 && whence == SEEK_CUR && stream->write_flag == 1)
    {
        stream->offset_base = -1;
    }
    if (stream->read_flag == 1)
    {
        ZeroMemory(stream->buffer, BUFSIZE);
        stream->offset_base = -1;
        stream->flushed = 0;
        stream->none_flag = 1;
        stream->write_flag = 0;
        stream->read_flag = 0;
    }
    return 0;
#endif
}

long so_ftell(SO_FILE *stream)
{
#if defined(__linux__)
    if (stream == NULL)
    {
        return -1;
    }
    if (stream->file_flag != 1)
    {
        stream->last_error = err_file_type;
        return -1;
    }
    return stream->offset_now;
#elif defined(_WIN32)
    if (stream == NULL)
    {
        return -1;
    }
    if (stream->file_flag != 1)
    {
        stream->last_error = err_file_type;
        return -1;
    }
    return stream->offset_now;
#endif
}

int so_fgetc(SO_FILE *stream)
{
#if defined(__linux__)
    if (stream == NULL)
        return SO_EOF;

    unsigned char result;
    int position;
    position = stream->offset_now - stream->offset_base;
    if (stream->is_eof == -1 || stream->is_eof == 0)
    {
        if (stream->to_eof != -1 && position == stream->to_eof)
        {
            stream->is_eof = 1;
        }
        else
        {
            stream->is_eof = 0;
        }
        if (stream->is_eof == 1)
        {
            return SO_EOF;
        }
    }

    if (stream->offset_now - stream->offset_base == BUFSIZE || stream->offset_base == -1)
    {
        if (stream->offset_base != -1)
        {
            memset(stream->buffer, 0, BUFSIZE);
            stream->offset_base = -1;
            stream->flushed = 0;
            stream->none_flag = 1;
        }
        int r_read;
        so_fseek(stream, stream->offset_now, SEEK_SET);
        stream->offset_base = stream->offset_now;
        r_read = read(stream->handle, stream->buffer, BUFSIZE);
        if (r_read < 0)
        {
            stream->last_error = err_read;
            return -1;
        }

        if (r_read < BUFSIZE)
        {
            stream->to_eof = r_read;
        }
        else
        {
            stream->to_eof = -1;
        }
    }
    result = stream->buffer[stream->offset_now - stream->offset_base];
    stream->offset_now++;
    stream->read_flag = 1;
    stream->none_flag = 0;
    stream->write_flag = 0;

    return result;
#elif defined(_WIN32)
    if (stream == NULL)
    {
        return -1;
    }
    int position;
    unsigned char result;

    position = stream->offset_now - stream->offset_base;

    if (stream->is_eof == -1 || stream->to_eof == 0)
    {
        if (stream->to_eof != -1 && position == stream->to_eof)
        {
            stream->is_eof = 1;
        }
        else
        {
            stream->is_eof = 0;
        }
        if (stream->is_eof == 1)
        {
            return -1;
        }
    }
    if (stream->offset_now - stream->offset_base == BUFSIZE || stream->offset_base == -1)
    {
        BOOL bRET;
        DWORD bytesREAD;
        if (stream == NULL)
        {
            return -1;
        }
        if (stream->offset_base != -1)
        {
            ZeroMemory(stream->buffer, BUFSIZE);
            stream->offset_base = -1;
            stream->flushed = 0;
            stream->none_flag = 1;
            stream->write_flag = 0;
            stream->read_flag = 0;
        }
        so_fseek(stream, stream->offset_now, SEEK_SET);
        stream->offset_base = stream->offset_now;
        bRET = ReadFile(stream->handle, stream->buffer, BUFSIZE, &bytesREAD, NULL);
        if (bRET == FALSE)
        {
            stream->last_error = err_read;
            return -1;
        }
        if (bytesREAD < BUFSIZE)
        {
            stream->to_eof = bytesREAD;
        }
        else
        {
            stream->to_eof = -1;
        }
    }

    result = stream->buffer[stream->offset_now - stream->offset_base];
    stream->offset_now++;
    stream->read_flag = 1;
    stream->none_flag = 0;
    stream->write_flag = 0;

    return result;
#endif
}

size_t so_fread(void *ptr, size_t size, size_t nmemb, SO_FILE *stream)
{
#if defined(__linux__)
    if (stream == NULL)
    {
        return -1;
    }
    if (ptr == NULL || size == 0 || nmemb == 0)
    {
        stream->last_error = err_invalid_mem;
        return -1;
    }

    int result;
    int ok = 1;
    char caracter;
    int i;

    for (i = 0; i < nmemb; i++)
    {
        for (int j = 0; j < size; j++)
        {
            result = so_fgetc(stream);

            if (result == SO_EOF)
            {
                //printf("FREAD: Am ajuns la eof\n");
                ok = 0;
                break;
            }
            caracter = (char)(result & 0x000000ff);
            *((char *)ptr + (i * size + j)) = caracter;
        }
        if (ok == 0)
        {
            break;
        }
    }
    if (ok == 0)
    {
        read(stream->handle, NULL, 0);
    }
    if (stream->file_flag != 1)
    {
        return 0;
    }
    return (size_t)i;
#elif defined(_WIN32)
    if (stream == NULL)
    {
        return -1;
    }
    if (ptr == NULL || size == 0 || nmemb == 0)
    {
        stream->last_error = err_invalid_mem;
        return -1;
    }

    int result;
    int ok = 1;
    char caracter;
    int i;
    BOOL bRET;

    for (i = 0; i < nmemb; i++)
    {
        for (int j = 0; j < size; j++)
        {
            result = so_fgetc(stream);
            if (result == SO_EOF)
            {
                ok = 0;
                break;
            }
            caracter = (char)(result & 0x000000ff);
            *((char *)ptr + (i * size + j)) = caracter;
        }
        if (ok == 0)
        {
            break;
        }
    }
    if (ok == 0)
    {
        bRET = ReadFile(stream->handle, NULL, 0, 0, NULL);
    }
    if (stream->file_flag != 1)
    {
        return -1;
    }
    return i;
#endif
}

int so_fputc(int c, SO_FILE *stream)
{
#if defined(__linux__)
    int result;
    if (stream == NULL)
    {
        return -1;
    }

    if (stream->offset_base == -1)
    {
        stream->offset_base = stream->offset_now;
    }

    if (stream->offset_now - stream->offset_base == BUFSIZE)
    {
        result = so_fflush(stream);
        if (result != 0)
        {
            stream->last_error = err_write;
            return -1;
        }
        stream->offset_base = stream->offset_now;
    }

    stream->buffer[stream->offset_now - stream->offset_base] = c;
    stream->offset_now++;
    stream->flushed = 1;
    stream->write_flag = 1;
    stream->read_flag = 0;
    stream->none_flag = 0;

    return c;
#elif defined(_WIN32)
    int result;
    if (stream == NULL)
    {
        return -1;
    }
    if (stream->offset_base == -1)
    {
        stream->offset_base = stream->offset_now;
    }
    if (stream->offset_now - stream->offset_base == BUFSIZE)
    {
        result = so_fflush(stream);
        if (result != 0)
        {
            stream->last_error = err_write;
            return -1;
        }
        stream->offset_base = stream->offset_now;
    }
    stream->buffer[stream->offset_now - stream->offset_base] = c;
    stream->offset_now++;
    stream->flushed = 1;
    stream->write_flag = 1;
    stream->read_flag = 0;
    stream->none_flag = 0;

    return c;

#endif
}

size_t so_fwrite(const void *ptr, size_t size, size_t nmemb, SO_FILE *stream)
{
#if defined(__linux__)
    if (stream == NULL)
    {
        return -1;
    }
    if (ptr == NULL || size == 0 || nmemb == 0)
    {
        stream->last_error = err_invalid_mem;
        return -1;
    }
    int i;
    int c;
    int result;
    int ok = 1;

    for (i = 0; i < nmemb; i++)
    {
        for (int j = 0; j < size; j++)
        {
            c = *((char *)ptr + (i * size + j));
            c = (c & 0x000000ff);

            result = so_fputc(c, stream);
            if (result == -1)
            {
                ok = 0;
                break;
            }
        }
        if (ok == 0)
        {
            break;
        }
    }
    return (size_t)i;
#elif defined(_WIN32)
    if (stream == NULL)
    {
        return -1;
    }
    if (ptr == NULL || size == 0 || nmemb == 0)
    {
        stream->last_error = err_invalid_mem;
        return -1;
    }
    int i;
    int c;
    int result;
    int ok = 1;

    for (i = 0; i < nmemb; i++)
    {
        for (int j = 0; j < size; j++)
        {
            c = *((char *)ptr + (i * size + j));
            c = (c & 0x000000ff);

            result = so_fputc(c, stream);
            if (result == -1)
            {
                ok = 0;
                break;
            }
        }
        if (ok == 0)
        {
            break;
        }
    }
    return (size_t)i;

#endif
}

int so_feof(SO_FILE *stream) 
{
#if defined(__linux__)
    if (stream == NULL)
    {
        return -1;
    }
    return stream->is_eof;
#elif defined(_WIN32)
    if (stream == NULL)
    {
        return -1;
    }
    return stream->is_eof;
#endif
}

int so_ferror(SO_FILE *stream) 
{
#if defined(__linux__)
    int res = 0;

    if (stream == NULL)
    {
        return -1;
    }
    if (stream->last_error != 0)
    {
        res = stream->last_error;
        stream->last_error = 0;
    }
    return res;
#elif defined(_WIN32)
    int res = 0;

    if (stream == NULL)
    {
        return -1;
    }
    if (stream->last_error != 0)
    {
        res = stream->last_error;
        stream->last_error = 0;
    }
    return res;
#endif
}

#if defined(__linux__)
int so_fileno(SO_FILE *stream)
{
    if (stream == NULL)
    {
        return -1;
    }
   // printf("FILENO:%d:done\n", stream->handle);
    return stream->handle;
}
#elif defined(_WIN32)

HANDLE so_fileno(SO_FILE *stream)
{
    if (stream == NULL)
    {
        return -1;
    }
    return stream->handle;
}

#endif

SO_FILE *so_popen(const char *command, const char *type)
{
    #if defined(__linux__)
    SO_FILE *result;
    int fd[2];
    int rc;
    pid_t pid;
    const char *argv[] = {"sh", "-c", command, NULL};

    if (command == NULL)
    {
        return NULL;
    }
    if (type == NULL)
    {
        return NULL;
    }

    result = malloc(sizeof(SO_FILE));

    if (strcmp(type, "r") == 0)
    {
        result->flag = O_RDONLY;
    }
    else if (strcmp(type, "w") == 0)
    {
        result->flag = O_WRONLY;
        result->mod = MODE;
    }
    else
    {
        return NULL;
    }

    result->process_flag = 1;
    result->file_flag = 0;
    result->offset_now = 0;
    result->last_error = 0;
    result->to_eof = -1;
    result->is_eof = 0;
    memset(result->buffer, 0, BUFSIZE);
    result->offset_base = -1;
    result->flushed = 0;
    result->none_flag = 1;
    result->read_flag = 0;
    result->write_flag = 0;

    rc = pipe(fd);
    if (rc != -1)
    {
        if (strcmp(type, "r") == 0)
        {
            result->handle = fd[0];
        }
        else
        {
            result->handle = fd[1];
        }
        pid = fork();

        switch (pid)
        {
        case -1:
            free(result);
            result = NULL;
            return NULL;
            break;
        case 0:
            if (strcmp(type, "r") == 0)
            {
                rc = close(fd[0]);
                if (rc < 0)
                {
                    return NULL;
                }
                rc = dup2(fd[1], STDOUT_FILENO);
                if (rc < 0)
                {
                    return NULL;
                }

                rc = close(fd[1]);
                if (rc < 0)
                {
                    return NULL;
                }
            }
            else
            {
                rc = close(fd[1]);

                if (rc < 0)
                {
                    return NULL;
                }
                rc = dup2(fd[0], STDIN_FILENO);

                if (rc < 0)
                {
                    return NULL;
                }

                rc = close(fd[0]);
                if (rc < 0)
                {
                    return NULL;
                }
            }

            rc = execvp(argv[0], (char *const *)argv);
            if (rc == -1)
            {
                return NULL;
            }
            exit(0);
            break;
        default:
            return result;
            break;
        }
    }
    else
    {
        free(result);
        return NULL;
    }

    return result;
    #elif defined(_WIN32)
    return NULL;
    #endif
}

int so_pclose(SO_FILE *stream)
{
    #if defined(__linux__)
    int rc;

    if (stream == NULL)
    {
        return -1;
    }

    if (stream->process_flag != 1)
    {
        stream->last_error = err_file_type;
        return -1;
    }
    if (stream->flushed > 0)
    {
        rc = so_fflush(stream);

        if (rc != 0)
        {
            return -1;
        }
    }
    rc = close(stream->handle);
    if (rc < 0)
    {
        stream->last_error = err_try_again;
        return -1;
    }

    // wait for child process and return code;
    waitpid(getpid(), &rc, 0);
    free(stream);
    stream = NULL;

    return WEXITSTATUS(rc);
    #elif defined(_WIN32)
    return 0;
    #endif
}
